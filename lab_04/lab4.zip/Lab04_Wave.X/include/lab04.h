#ifndef LAB04_H
#define	LAB04_H

// initialized the timer for task 2
void timer_initialize();

// contains the loop code from task 1, 2 and 3
void main_loop();

#endif	/* LAB04_H */
